package vn.devpro.unit8.exercise;

import java.util.ArrayList;
import java.util.Scanner;

public class ManagementUtils {
	
	static ArrayList<ProductType> ptList = new ArrayList<ProductType>();
	static ArrayList<Products> pList = new ArrayList<Products>();
	static ArrayList<Customers>cList = new ArrayList<Customers>();
	static ShoppingCart shop = new ShoppingCart();
	
	static Scanner in = new Scanner(System.in);
	
	
	//
	public static void menu() {
		do {
			System.out.println("-----CHUONG TRINH QUAN LY BAN HANG-----");
			System.out.println("Chon mot trong cac chuc nang");
			System.out.println("\t1. Quan ly danh sach loai hang");
			System.out.println("\t2. Quan ly danh sach hang hoa");
			System.out.println("\t3. Quan ly khach hang");
			System.out.println("\t4. Quan ly gio hang cua khach");
			System.out.println("\t5. Thoat chuong trinh");
			System.out.println("Hay chon 1 chuc nang: ");
			int choose = in.nextInt();
			
			switch(choose) {
				case 1: productTypeUpdate(); break;
				case 2: productUpdate(); break;
				case 3: customerUpdate(); break;
				case 4: shoppingCartManage(); break;
				case 5: return;
				default: System.out.println("Khong hop le, chon lai");
			}
		}while (true);
	}
	//
	
	
//==========================================================================================//
	// HOAN THIEN PHAN CON THIEU - QUAN LY THONG TIN KHACH HANG...
	public static void addCustomer() {
		System.out.println("Nhap thong tin khach hang.");
		System.out.print("\tID khach hang: ");
		int ID = in.nextInt();
		if (indexOfCustomer(ID) != -1) {
			System.out.println("\tMa loai hang da ton tai");
			return;
		}
		
		System.out.print("\tTen khach hang: ");
		in.nextLine();
		String name = in.nextLine();
		Customers customer = new Customers(ID, name);
		cList.add(customer);
	}
	//
	
	//
	public static void updateCustomer() {
		System.out.println("Sua thong tin khach hang.");
		System.out.print("\tNhap ma khach hang can sua: ");
		int ID = in.nextInt();
		int index = indexOfCustomer(ID);
		if (index == -1) {
			System.out.println("\tMa khach hang khong ton tai.");
			return;
		}
		System.out.print("\tTen khach hang: ");
		in.nextLine();
		String name = in.nextLine();
		Customers customer = new Customers(ID, name);
		cList.set(index, customer);
	}
	//
	
	//
	public static void removeCustomer() {
		System.out.println("\nXoa thong tin khach hang.");
		System.out.print("\tNhap ma khach hang can xoa: ");
		int ID = in.nextInt();
		int index = indexOfCustomer(ID);
		if (index == -1) {
			System.out.println("\tMa khach hang khong ton tai.");
			return;
		}
		cList.remove(index);
	}
	//
	
	//
	public static void displayCustomer() {
		System.out.println("\nDanh sach khach hang");
		for (Customers customer : cList) {
			System.out.println("\t" + customer.getID() + "\t" + customer.getName());
		}
	}
	//
	
	public static void customerUpdate() {
		do {
			System.out.println("\nCap nhat danh sach khach hang.");
			System.out.println("\t1. Them khach hang.");
			System.out.println("\t2. Sua thong tin khach hang.");
			System.out.println("\t3. Xoa khach hang.");
			System.out.println("\t4. Xem danh sach khach hang.");
			System.out.println("\t5. Quay lai");
			System.out.print("Nhap lua chon cua ban: ");
			int choice = in.nextInt();
			switch (choice) {
				case 1: addCustomer(); break;
				case 2: updateCustomer(); break;
				case 3: removeCustomer(); break;
				case 4: displayCustomer(); break;
				case 5: return;
			}
		} while (true);
	}
//==========================================================================================//
	
	
	//Phan cap nhat danh sach loai hang
	public static void productTypeUpdate() {
		int choice;
		System.out.println("Cap nhat danh sach loai hang");
		System.out.println("\t1. Them loai hang");
		System.out.println("\t2. Sua loai hang");
		System.out.println("\t3. Xoa loai hang");
		System.out.println("\t4. Xem danh sach loai hang");
		System.out.println("\t5. Quay lai");
		do {
			System.out.print("Chon 1 chuc nang: ");
			choice = in.nextInt();
			switch (choice) {
				case 1: addProductType(); break;
				case 2: updateProductType(); break;
				case 3: removeProductType(); break;
				case 4: displayListProductType(); break;
				case 5: return;
			}
		}while (true);
	}
	//
	public static int indexOfProductType(int ID) {
		int i=0;
		while (i < ptList.size()) {
			if (ptList.get(i).getID() == ID)
				return i;
			i++;
		}
		return -1;
	}
	//
	public static void addProductType() {
		System.out.println("Nhap thong tin loai hang");
		System.out.print("\tID: ");
		int ID = in.nextInt();
		if (indexOfProductType(ID) != -1) {
			System.out.println("\tMa loai hang da ton tai");
			return;
		}
		System.out.print("\tTen loai hang: ");
		in.nextLine();
		String name = in.nextLine();
		ProductType pt = new ProductType(ID, name);
		ptList.add(pt);
	}
	//
	public static void updateProductType() {
		System.out.println("Sua thong tin loai hang");
		System.out.print("\tNhap ma loai hang can sua: ");
		int ID = in.nextInt();
		int index = indexOfProductType(ID);
		if (index == -1) {
			System.out.println("\tLoai hang khong co trong DS");
			return;
		}
		System.out.print("\tTen loai hang: ");
		in.nextLine();
		String name = in.nextLine();
		ProductType pt = new ProductType(ID, name);
		ptList.set(index, pt);
	}
	//
	public static void removeProductType() {
		System.out.println("\nXoa thong tin loai hang");
		System.out.print("\tNhap ma loai hang can xoa: ");
		int ID = in.nextInt();
		int index = indexOfProductType(ID);
		if (index == -1) {
			System.out.println("\tLoai hang khong co trong DS");
			return;
		}
		ptList.remove(index);
	}
	//
	public static void displayListProductType() {		
		System.out.println("\nDanh sach loai hang");
		for (ProductType pt : ptList) {
			System.out.println("\t" + pt.getID() + "\t" + pt.getName());
		}
	}
	//
	
	
		//Phan cap nhat danh sach hang hoa	
		public static void productUpdate() {
			int choice;
			System.out.println("\nCap nhat danh sach hang hoa");
			System.out.println("\t1. Them hang hoa");
			System.out.println("\t2. Sua thong tin hang hoa");
			System.out.println("\t3. Xoa hang hoa");
			System.out.println("\t4. Xem danh sach hang hoa");
			System.out.println("\t5. Quay lai");
			do {
				System.out.print("Chon 1 chuc nang: ");
				choice = in.nextInt();
				switch (choice) {
					case 1: addProduct(); break;
					case 2: updateProduct(); break;
					case 3: removeProduct(); break;
					case 4: displayListProduct(); break;
					case 5: return;
				}
			}while (true);
		}
		//
		public static String getIdProductType() {
			String s = "[ ";
			for (ProductType pt : ptList)
				s += pt.getID() + " ";
			s += "]";
			return s;
		}
		//
		public static int indexOfProduct(int ID) {
			int i=0;
			while (i < pList.size()) {
				if (pList.get(i).getID() == ID)
					return i;
				i++;
			}
			return -1;
		}
		//
		public static void addProduct() {
			System.out.println("\nNhap thong tin hang hoa");
			//CHon loai hang cho hang hoa
			String s = getIdProductType();
			System.out.print("\tMa loai hang " + s + ": ");
			int ptID = in.nextInt();
			if (indexOfProductType(ptID) == -1) {
				System.out.println("\tMa loai hang chua co");
				return;
			}			
			System.out.print("\tID: ");
			int ID = in.nextInt();
			if (indexOfProduct(ID) != -1) {
				System.out.println("\tMa hang hoa da ton tai");
				return;
			}
			
			System.out.print("\tTen hang hoa: ");
			in.nextLine();
			String name = in.nextLine();
			System.out.print("\tSo luong hang hoa: ");
			int amount = in.nextInt();
			System.out.print("\tDon gia hang: ");
			double price = in.nextDouble();
			Products p = new Products(ptID, ID, name, amount, price);
			pList.add(p);
		}
		//
		public static void updateProduct() {
			System.out.println("Sua thong tin hang hoa");
			System.out.print("\tNhap ma hang hoa can sua: ");
			int ID = in.nextInt();
			int index = indexOfProduct(ID);
			if (index == -1) {
				System.out.println("\tHang hoa khong co trong DS");
				return;
			}
			String s = getIdProductType();
			System.out.print("\tMa loai hang " + s + ": ");
			int ptID = in.nextInt();
			if (indexOfProductType(ptID) == -1) {
				System.out.println("\tMa loai hang chua co");
				return;
			}			
			System.out.print("\tTen hang hoa: ");
			in.nextLine();
			String name = in.nextLine();
			System.out.print("\tSo luong hang hoa: ");
			int amount = in.nextInt();
			System.out.print("\tDon gia hang: ");
			double price = in.nextDouble();
			Products p = new Products(ptID, ID, name, amount, price);
			pList.set(index, p);
		}
		//
		public static void removeProduct() {
			System.out.println("\nXoa thong tin hang hoa");
			System.out.print("\tNhap ma hang hoa can xoa: ");
			int ID = in.nextInt();
			int index = indexOfProduct(ID);
			if (index == -1) {
				System.out.println("\tHang hoa khong co trong DS");
				return;
			}
			pList.remove(index);
		}
		//
		public static void displayListProduct() {		
			System.out.println("\nDanh sach hang hoa");
			for (Products p : pList) {
				System.out.println("\t" + p.toString());
			}
		}
		
		
	//Cap nhat gio hang cua khach mua hang
	public static String getCustomerName(int ID) {
		for (Customers cs : cList) {
			if (cs.getID() == ID)
				return cs.getName();
		}
		return null;
	}
	//
	public static String getProductName(int ID) {
		for (Products p : pList)
			if (p.getID() == ID)
				return p.getName();
		return null;
	}
	//
	public static int getProductAmount(int ID) {
		for (Products p : pList)
			if (p.getID() == ID)
				return p.getAmount();
		return 0;
	}
	//
	public static double getProductPrice(int ID) {
		for (Products p : pList)
			if (p.getID() == ID)
				return p.getPrice();
		return 0;
	}
	//
	public static int indexOfCustomer(int ID) {
		for (int i = 0; i<cList.size(); i++)
			if (cList.get(i).getID() == ID)
				return i;
		return -1;
	}
	
	
	//
	public static String getIdCustomer() {
		String s = "[ ";
		for (Customers cs : cList)
			s += cs.getID() + " ";
		s += "]";
		return s;
	}
	//
	
	//
	public static String getIdProduct() {
		String s = "[ ";
		for (Products p : pList)
			s += p.getID() + " ";
		s += "]";
		return s;
	}
	//
	
	
//===============================================================================================================//
	
	// SUA PHAN QUAN LY GIO HANG...
	public static void makeNewProductToCart() {
		System.out.println("--------> Tao moi gio hang <-------");
		System.out.print("\tNhap ma gio hang: ");
		int ID = in.nextInt();
		System.out.print("\t\tNhap ma khach hang: ");
		int cusID = in.nextInt();
		if (indexOfCustomer(cusID) == -1) {
			System.out.println("\tMa khach hang khong ton tai.");
			return;
		}
		shop.setID(ID);
		shop.setCusID(cusID);
	}
	
	public static void addProductToCart() {
		//String s = getIdProduct();
		System.out.print("\tNhap ma hang: ");
		int productID = in.nextInt();
		if (indexOfProduct(productID) == -1) {
			System.out.println("\tHang hoa nay khong ton tai.");
			return;
		}
		System.out.print("\tSo luong mua: ");
		int buyAmount = in.nextInt();
		
		int index = shop.indexOfCartProduct(productID);
		if (index != - 1) {
			CartProduct newCartProduct = shop.getOneProduct(index);
			int newAmount = buyAmount + newCartProduct.getAmount();
			if (newAmount > getProductAmount(productID)) {
				System.out.println("\\tSo luong mua khong duoc nhieu hon so luong cua hang co la " + getProductAmount(productID));
				return;
			} else {
				newCartProduct.setAmount(newAmount);
				shop.setOneProduct(index, newCartProduct);
			}
		} else {
			if (buyAmount > getProductAmount(productID)) {
				System.out.println("\\tSo luong mua khong duoc nhieu hon so luong cua hang co la " + getProductAmount(productID));
				return;
			}
			CartProduct cp = new CartProduct(productID, buyAmount);
			shop.setProduct(cp);
		}
	}
	//
	
	//
	public static void deleteProductFromCart(){
		System.out.println("Xoa hang hoa da chon mua trong gio hang");
		System.out.print("\tNhap ma hang can xoa: ");
		int productId = in.nextInt();
		int index = shop.indexOfCartProduct(productId); //Lay index theo ID
		if (index == -1) {
			System.out.println("\tHang khong co trong gio");
			return;
		}
		shop.removeOneProduct(index);
		System.out.println("\tDa xoa hang trong gio...!");
	}
	//
	
	//
	public static void displayShoppingCart() {
		System.out.println("\nGio hang cua ban");
		System.out.println("\tMa gio hang: " + shop.getID());
		System.out.println("\tTen khach hang: " + 
				getCustomerName(shop.getCusID()));
		System.out.println("\tDanh sach hang hoa");
		ArrayList<CartProduct> list = new ArrayList<CartProduct>();
		list = shop.getProduct();
		double thanhTien = 0, tongTien = 0;
		for (CartProduct cp : list) {
			System.out.print("\t" + getProductName(cp.getProductID()));
			System.out.print("\t" + cp.getAmount());
			System.out.print("\t" + getProductPrice(cp.productID));
			thanhTien = getProductPrice(cp.productID) * cp.getAmount();
			System.out.println("\t" + thanhTien);
			tongTien += thanhTien;
		}
		System.out.println("\t\t\tCong thanh tien: " + tongTien);
	}
	//
	
	//
	public static void shoppingCartManage() { 
		System.out.println("\nQuan ly gio hang");
		do {
			System.out.println("Chon chuc nang quan ly gio hang");
			System.out.println("\t1. Tao moi thong tin gio hang.");
			System.out.println("\t2. Them hang gio hang.");
			System.out.println("\t2. Xoa hang khoi gio hang.");
			System.out.println("\t3. Xem gio hang.");
			System.out.println("\t4. Quay lai.");
			System.out.print("Nhap lua chon cua ban: ");
			int chon = in.nextInt();
			switch (chon) {
				case 1: makeNewProductToCart(); break;
				case 2: addProductToCart(); break;
				case 3: deleteProductFromCart(); break;
				case 4: displayShoppingCart(); break;
				case 5: return;
			}
		}while (true);
	}
	
//===============================================================================================================//

	public static void main(String[] args) {
		cList.add(new Customers(1, "Trang"));
		cList.add(new Customers(2, "Duong"));
		menu();
	}

}
