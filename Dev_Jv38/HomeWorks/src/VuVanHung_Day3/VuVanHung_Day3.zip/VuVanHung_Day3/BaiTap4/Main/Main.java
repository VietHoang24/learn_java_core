package VuVanHung_Day3.BaiTap4.Main;

import VuVanHung_Day3.BaiTap4.Menu.Menu;

public class Main {
    public static void main(String[] args) {
        Menu.menu();
    }
}
