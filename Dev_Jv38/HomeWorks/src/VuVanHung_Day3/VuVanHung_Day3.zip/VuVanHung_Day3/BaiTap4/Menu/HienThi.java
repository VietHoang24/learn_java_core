package VuVanHung_Day3.BaiTap4.Menu;

public class HienThi {
    public static void listMenu(){
        System.out.println("\n========== MENU ==========");
        System.out.println("1. Kiem tra so nguyen to.");
        System.out.println("2. Tong cua n so nguyen to dau tien.");
        System.out.println("3. Bang cuu chuong 2-10.");
        System.out.println("4. Tinh sin(x).");
        System.out.println("5. Day Fibonacci.");
        System.out.println("6. Thoat chuong trinh !!\n");
    }
}
