package VuVanHung_Day3.BaiTap2.Menu;

public class HienThiMenu {
    public static void hienThi(){
        System.out.println("\n========== MENU ==========");
        System.out.println("1. Doc chu so.");
        System.out.println("2. Tinh gia tri bieu thuc.");
        System.out.println("3. Tinh tien mua gao.");
        System.out.println("4. Tam giac.");
        System.out.println("5. Thoat chuong trinh.\n");
    }
}
