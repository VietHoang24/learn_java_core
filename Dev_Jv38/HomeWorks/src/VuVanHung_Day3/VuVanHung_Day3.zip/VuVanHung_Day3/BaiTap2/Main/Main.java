package VuVanHung_Day3.BaiTap2.Main;

import VuVanHung_Day3.BaiTap2.Menu.Menu;

public class Main {
    public static void main(String[] args) {
        Menu.menu();
    }
}
